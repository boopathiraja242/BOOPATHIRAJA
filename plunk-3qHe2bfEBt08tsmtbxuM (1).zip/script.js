(function(){
 var app = angular.module('sam',[]);
 app.controller('samcontroller',function(
   ){
	 this.product=s;
	 console.log("script execute");
});

var s=
[{
	name: 'karpagam',
	code:8.5,
	description: 'COIMBATORE',
},
{
	name: 'paavai',
	code:7.5,
	description: 'NAMMAKAL',
},
{
	name: 'kongu',
	code:7.0,
	description: 'PERUNDURAI',
}];
})();
